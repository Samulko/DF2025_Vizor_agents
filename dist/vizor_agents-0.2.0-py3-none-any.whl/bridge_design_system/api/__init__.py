"""API module for real-time status broadcasting."""
