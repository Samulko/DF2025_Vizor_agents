"""
Utility functions for Grasshopper MCP.

This package contains utility functions used throughout the Grasshopper MCP bridge.
"""
